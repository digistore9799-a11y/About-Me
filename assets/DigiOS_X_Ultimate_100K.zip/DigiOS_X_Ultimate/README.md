# DigiOS X Ultimate

Large educational virtual operating environment in Python.
Run: `python main.py`
GUI: `python launcher.py`
Admin: `admin / admin123`
