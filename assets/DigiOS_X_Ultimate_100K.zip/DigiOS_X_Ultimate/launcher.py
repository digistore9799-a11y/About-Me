import tkinter as tk
from digios.core.kernel import DigiKernel
from digios.ui.desktop import Desktop
k=DigiKernel(); k.db.initialize(); k.auth.ensure_admin(); Desktop(k).run()
