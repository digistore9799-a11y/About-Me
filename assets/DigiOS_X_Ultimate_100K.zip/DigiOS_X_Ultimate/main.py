from digios.core.kernel import DigiKernel
if __name__ == "__main__": DigiKernel().boot()
