class PermissionManager:
 def allowed(self,role,perm): return role=='admin' or perm in {'read','write','bank','market','files','chat'}
