import hashlib,secrets
def hash_password(p,s=None):
 s=s or secrets.token_hex(16);return s+'$'+hashlib.pbkdf2_hmac('sha256',p.encode(),s.encode(),120000).hex()
def verify_password(p,x):
 try:s,d=x.split('$',1);return hash_password(p,s).split('$',1)[1]==d
 except:return False
