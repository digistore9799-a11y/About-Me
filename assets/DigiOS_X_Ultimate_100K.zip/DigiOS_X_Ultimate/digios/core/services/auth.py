from datetime import datetime
from ..security.hash import hash_password,verify_password
class AuthService:
 def __init__(self,db):self.db=db
 def ensure_admin(self):
  if not self.db.one("SELECT id FROM users WHERE username='admin'"):self.db.execute("INSERT INTO users(username,password,display_name,role,created_at) VALUES(?,?,?,?,?)",('admin',hash_password('admin123'),'System Administrator','admin',datetime.now().isoformat()))
 def login(self,u,p):
  r=self.db.one('SELECT * FROM users WHERE username=?',(u,));return dict(r) if r and not r['blocked'] and verify_password(p,r['password']) else None
 def register(self,u,p,n):
  try:self.db.execute('INSERT INTO users(username,password,display_name,created_at) VALUES(?,?,?,?)',(u,hash_password(p),n,datetime.now().isoformat()));return True
  except:return False
