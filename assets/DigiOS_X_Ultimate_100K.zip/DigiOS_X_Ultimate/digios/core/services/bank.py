from datetime import datetime
class BankService:
 def __init__(self,k):self.k=k
 def handle(self,u,a):
  if not u:return 'Login required.'
  if not a:return 'bank balance|deposit <amount>|withdraw <amount>|history'
  if a[0]=='balance':return f"Balance: {u['balance']:.2f} DGT"
  if len(a)!=2:return 'Amount required.'
  x=float(a[1])
  if a[0]=='deposit' and x>0:self.k.db.execute('UPDATE users SET balance=balance+? WHERE id=?',(x,u['id']));return 'Deposit successful.'
  if a[0]=='withdraw' and 0<x<=u['balance']:self.k.db.execute('UPDATE users SET balance=balance-? WHERE id=?',(x,u['id']));return 'Withdrawal successful.'
  return 'Operation failed.'
