from pathlib import Path
class Config:
 def __init__(self):
  self.root=Path(__file__).resolve().parents[2]; self.data=self.root/'data'; self.data.mkdir(exist_ok=True); self.database=self.data/'digios.db'; self.log=self.data/'system.log'; self.version='X.0 Ultimate'; self.currency='DGT'
