import shlex,os
class Router:
 def __init__(self,k):self.k=k;self.user=None
 def dispatch(self,line):
  a=shlex.split(line);
  if not a:return ''
  c=a[0].lower();p=a[1:]
  if c=='help':return 'help login logout whoami users system bank balance market crypto network backup exit'
  if c=='login':
   if len(p)!=2:return 'login <user> <pass>'
   self.user=self.k.auth.login(*p);return 'Login successful.' if self.user else 'Login failed.'
  if c=='logout':self.user=None;return 'Logged out.'
  if c=='whoami':return str(self.user)
  if c=='system':return self.k.config.version+' | Python virtual environment'
  if c=='users':return '\n'.join(str(dict(x)) for x in self.k.db.all('SELECT id,username,display_name,role,balance FROM users'))
  if c=='bank':from .services.bank import BankService;return BankService(self.k).handle(self.user,p)
  if c=='backup':return self.k.db.backup()
  if c=='clear':os.system('cls' if os.name=='nt' else 'clear');return ''
  if c=='exit':raise SystemExit
  return 'Unknown command. Type help.'
