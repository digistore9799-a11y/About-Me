import sqlite3,shutil
from datetime import datetime
class Database:
 def __init__(self,path): self.path=path
 def connect(self):
  c=sqlite3.connect(self.path); c.row_factory=sqlite3.Row; return c
 def initialize(self):
  with self.connect() as c:
   c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,display_name TEXT,role TEXT DEFAULT 'user',balance REAL DEFAULT 1000,wallet REAL DEFAULT 500,blocked INTEGER DEFAULT 0,created_at TEXT);CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY,user_id INTEGER,kind TEXT,amount REAL,note TEXT,created_at TEXT);CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY,kind TEXT,content TEXT,created_at TEXT);CREATE TABLE IF NOT EXISTS assets(symbol TEXT PRIMARY KEY,name TEXT,price REAL,change REAL);CREATE TABLE IF NOT EXISTS plugins(name TEXT PRIMARY KEY,version TEXT,enabled INTEGER DEFAULT 1);""")
 def execute(self,q,p=()):
  with self.connect() as c:return c.execute(q,p).lastrowid
 def one(self,q,p=()):
  with self.connect() as c:return c.execute(q,p).fetchone()
 def all(self,q,p=()):
  with self.connect() as c:return c.execute(q,p).fetchall()
 def backup(self):
  out=self.path.with_name('backup_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.db');shutil.copy2(self.path,out);return str(out)
