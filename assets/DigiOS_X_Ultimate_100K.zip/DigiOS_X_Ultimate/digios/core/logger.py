from datetime import datetime
class Logger:
 def __init__(self,path): self.path=path
 def _w(self,l,m): open(self.path,'a',encoding='utf8').write(f"{datetime.now().isoformat()} [{l}] {m}\n")
 def info(self,m): self._w('INFO',m)
 def warning(self,m): self._w('WARN',m)
 def error(self,m): self._w('ERROR',m)
