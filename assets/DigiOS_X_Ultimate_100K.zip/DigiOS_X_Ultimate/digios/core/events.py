class EventBus:
 def __init__(self): self.listeners={}
 def on(self,e,fn): self.listeners.setdefault(e,[]).append(fn)
 def emit(self,e,data=None):
  for fn in self.listeners.get(e,[]): fn(data)
