from .config import Config
from .logger import Logger
from .storage.database import Database
from .services.auth import AuthService
from .router import Router
class DigiKernel:
 def __init__(self):
  self.config=Config();self.logger=Logger(self.config.log);self.db=Database(self.config.database);self.auth=AuthService(self.db);self.router=Router(self)
 def boot(self):
  self.db.initialize();self.auth.ensure_admin();print('=== DIGIOS X ULTIMATE ===');print("Type 'help'. Default admin: admin / admin123")
  while True:
   try:print(self.router.dispatch(input('DigiOS> ')))
   except SystemExit:print('Shutdown complete.');break
   except Exception as e:print('Error:',e)
