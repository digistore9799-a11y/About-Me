import tkinter as tk
from tkinter import messagebox
class Desktop:
 def __init__(self,k):
  self.k=k;self.root=tk.Tk();self.root.title('DigiOS X Ultimate');self.root.geometry('1100x700');self.build()
 def build(self):
  tk.Label(self.root,text='DigiOS X Ultimate',font=('Arial',24,'bold')).pack(pady=20)
  for i,n in enumerate(['Terminal','Files','Browser','Chat','Mail','Bank','Market','Crypto','Games','Settings','Admin','Developer']):tk.Button(self.root,text=n,width=18,height=3,command=lambda x=n:self.open(x)).grid(row=i//4,column=i%4,padx=20,pady=15)
 def open(self,n):messagebox.showinfo(n,n+' module loaded')
 def run(self):self.root.mainloop()
